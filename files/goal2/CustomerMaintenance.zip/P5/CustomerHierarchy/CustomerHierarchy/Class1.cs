﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerHierarchy
{
    //**************************CUSTOMERS****************************
    public class Customers
    {
        string strFullName, strEmail;

        //Constructor
        public Customers(string first, string last, string email)
        {
            if (string.IsNullOrWhiteSpace(first) || string.IsNullOrWhiteSpace(last) || string.IsNullOrWhiteSpace(email))
            {
                throw new IncompleteInformationException();
            }

            else
            {
                strFullName = first.Trim(' ') + " " + last.Trim(' ');
                strEmail = email;
            }
        }

        //Properties
        public string FullName
        {
            get => strFullName;

            set
            {
                strFullName = value;
            }
        }


        //Method
        public virtual string GetDisplayText()
        {
            return strFullName + ", " + strEmail.Trim(' ');
        }


        //Exceptions
        public class IncompleteInformationException : ApplicationException
        {
            //Customised exception message
            public IncompleteInformationException(string message) : base(message)
            {
            }//end constructor

            //Defaut exception message  
            public IncompleteInformationException() : base("All fields are required. Please fill up all four textboxes.")
            {
            }//end constructor
        }
    }//end Customers class


    //****************************WHOLESALE******************************
    public class Wholesale:Customers
    {
        string strFullName, strEmail, strCompany;

        //Constructor
        public Wholesale(string first, string last, string email, string company):base(first, last, email)
        {
            if (string.IsNullOrWhiteSpace(first) || string.IsNullOrWhiteSpace(last) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(company))
            {
                throw new IncompleteInformationException();
            }

            else
            {
                strFullName = first.Trim(' ') + " " + last.Trim(' ');
                strEmail = email.Trim(' ');
                strCompany = company.Trim(' ');
            }
        }

        //Method
        public override string GetDisplayText()
        {
            return strFullName + ", " + strEmail + "(" + strCompany + ")";
        }
    }//end Wholesale class


    //****************************RETAIL******************************
    public class Retail:Customers
    {
        string strFullName, strEmail, strPhone;

        //Constructor
        public Retail(string first, string last, string email, string phone):base(first, last, email)
        {
            if (string.IsNullOrWhiteSpace(first) || string.IsNullOrWhiteSpace(last) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(phone))
            {
                throw new IncompleteInformationException();
            }

            else
            {
                strFullName = first.Trim(' ') + " " + last.Trim(' ');
                strEmail = email;
                strPhone = phone;
            }
        }

        //Method
        public override string GetDisplayText()
        {
            return strFullName + ", " + strEmail + ", ph:" + strPhone.ToString();
        }
    }//end Retail class
}//end namespace
