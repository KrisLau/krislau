﻿using System;
using System.Windows.Forms;
using CustomerHierarchy;

namespace CustomerMaintananceApp
{
    public partial class frmAddRetail : Form
    {
        string strItem;
        Retail retailCustomer;

        public frmAddRetail()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                retailCustomer = new Retail(txtBxFirst.Text, txtBxLast.Text, txtBxEmail.Text, txtBxPhone.Text);

                frmCustomerMaintenance maintenanceForm = new frmCustomerMaintenance();
                strItem = retailCustomer.GetDisplayText();
                this.Close();
            }

            catch (Customers.IncompleteInformationException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //**************************PROPERTIES****************************
        public Retail rCustomer
        {
            get
            {
                return retailCustomer;
            }
            set
            {
                retailCustomer = value;
            }
        }

        public string Item
        {
            get
            {
                return strItem;
            }

            set
            {
                strItem = value;
            }
        }
    }
}
