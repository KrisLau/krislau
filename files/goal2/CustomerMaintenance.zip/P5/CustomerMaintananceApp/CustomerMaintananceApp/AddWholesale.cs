﻿using System;
using System.Windows.Forms;
using CustomerHierarchy;

namespace CustomerMaintananceApp
{
    public partial class frmAddWholesale : Form
    {
        string strItem;
        Wholesale wholesaleCustomer;

        public frmAddWholesale()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                wholesaleCustomer = new Wholesale(txtBxFirst.Text, txtBxLast.Text, txtBxEmail.Text, txtBxCompany.Text);

                frmCustomerMaintenance maintenanceForm = new frmCustomerMaintenance();
                strItem = wholesaleCustomer.GetDisplayText();
                this.Close();
            }

            catch (Customers.IncompleteInformationException ex)
            {
                MessageBox.Show(ex.Message);
            }        
        }


        //**************************PROPERTIES****************************
        public Wholesale wCustomer
        {
            get
            {
                return wholesaleCustomer;
            }

            set
            {
                wholesaleCustomer = value;
            }
        }

        public string Item
        {
            get
            {
                return strItem;
            }

            set
            {
                strItem = value;
            }
        }
    }
}
