﻿namespace CustomerMaintananceApp
{
    partial class frmCustomerMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCustomers = new System.Windows.Forms.Label();
            this.lstBxCustomers = new System.Windows.Forms.ListBox();
            this.btnAddWholesale = new System.Windows.Forms.Button();
            this.btnAddRetail = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCustomers
            // 
            this.lblCustomers.AutoSize = true;
            this.lblCustomers.Location = new System.Drawing.Point(44, 35);
            this.lblCustomers.Name = "lblCustomers";
            this.lblCustomers.Size = new System.Drawing.Size(79, 17);
            this.lblCustomers.TabIndex = 0;
            this.lblCustomers.Text = "Customers:";
            // 
            // lstBxCustomers
            // 
            this.lstBxCustomers.FormattingEnabled = true;
            this.lstBxCustomers.ItemHeight = 16;
            this.lstBxCustomers.Location = new System.Drawing.Point(47, 73);
            this.lstBxCustomers.Name = "lstBxCustomers";
            this.lstBxCustomers.Size = new System.Drawing.Size(548, 308);
            this.lstBxCustomers.TabIndex = 1;
            // 
            // btnAddWholesale
            // 
            this.btnAddWholesale.Location = new System.Drawing.Point(655, 73);
            this.btnAddWholesale.Name = "btnAddWholesale";
            this.btnAddWholesale.Size = new System.Drawing.Size(185, 52);
            this.btnAddWholesale.TabIndex = 2;
            this.btnAddWholesale.Text = "Add &Wholesale";
            this.btnAddWholesale.UseVisualStyleBackColor = true;
            this.btnAddWholesale.Click += new System.EventHandler(this.btnAddWholesale_Click);
            // 
            // btnAddRetail
            // 
            this.btnAddRetail.Location = new System.Drawing.Point(655, 158);
            this.btnAddRetail.Name = "btnAddRetail";
            this.btnAddRetail.Size = new System.Drawing.Size(185, 52);
            this.btnAddRetail.TabIndex = 3;
            this.btnAddRetail.Text = "Add &Retail";
            this.btnAddRetail.UseVisualStyleBackColor = true;
            this.btnAddRetail.Click += new System.EventHandler(this.btnAddRetail_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(655, 243);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(185, 52);
            this.btnDelete.TabIndex = 4;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(655, 328);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(185, 52);
            this.btnExit.TabIndex = 5;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmCustomerMaintenance
            // 
            this.AcceptButton = this.btnAddRetail;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 434);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnAddRetail);
            this.Controls.Add(this.btnAddWholesale);
            this.Controls.Add(this.lstBxCustomers);
            this.Controls.Add(this.lblCustomers);
            this.Name = "frmCustomerMaintenance";
            this.Text = "Customer Maintenance";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCustomers;
        private System.Windows.Forms.ListBox lstBxCustomers;
        private System.Windows.Forms.Button btnAddWholesale;
        private System.Windows.Forms.Button btnAddRetail;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnExit;
    }
}

