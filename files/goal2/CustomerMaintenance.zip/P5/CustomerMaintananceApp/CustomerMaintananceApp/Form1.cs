﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using CustomerHierarchy;

namespace CustomerMaintananceApp
{
    public partial class frmCustomerMaintenance : Form
    {
        List<Customers> lstCustomers = new List<Customers>();

        public frmCustomerMaintenance()
        {
            InitializeComponent();
        }


        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void btnDelete_Click(object sender, EventArgs e)
        {
            //Declare variables
            DialogResult dialogResult;
            string strFirst;

            //Confirm operation
            strFirst = lstBxCustomers.SelectedItem.ToString();
            strFirst = strFirst.Substring(0, strFirst.IndexOf(','));

            dialogResult = MessageBox.Show("Are you sure you want to delete " + strFirst + "?", "Confirm Delete", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                lstBxCustomers.Items.RemoveAt(lstBxCustomers.SelectedIndex);
                lstCustomers.RemoveAt(lstBxCustomers.SelectedIndex + 1);
            }

            else
            {                
                MessageBox.Show(strFirst + " not deleted.", "Cancelled");
            }
        }


        private void btnAddWholesale_Click(object sender, EventArgs e)
        {
            frmAddWholesale wholesaleForm = new frmAddWholesale();
            wholesaleForm.ShowDialog();
            if(wholesaleForm.Item != null)
            {
                lstBxCustomers.Items.Add(wholesaleForm.Item);
            }
            if (wholesaleForm.wCustomer != null)
            {
                lstCustomers.Add(wholesaleForm.wCustomer);
            }
        }


        private void btnAddRetail_Click(object sender, EventArgs e)
        {
            frmAddRetail retailForm = new frmAddRetail();
            retailForm.ShowDialog();
            if (retailForm.Item != null)
            {
                lstBxCustomers.Items.Add(retailForm.Item);
            }
            if (retailForm.rCustomer != null)
            {
                lstCustomers.Add(retailForm.rCustomer);
            }
        }
    }//end class
}//end namespace
