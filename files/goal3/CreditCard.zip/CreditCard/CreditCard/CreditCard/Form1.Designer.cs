﻿namespace CreditCard
{
    partial class frmCreditCard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCreditCard));
            this.lblName = new System.Windows.Forms.Label();
            this.lblAccountNo = new System.Windows.Forms.Label();
            this.lblBalance = new System.Windows.Forms.Label();
            this.lblCharge = new System.Windows.Forms.Label();
            this.lblPayment = new System.Windows.Forms.Label();
            this.txtBxName = new System.Windows.Forms.TextBox();
            this.txtBxAccountNo = new System.Windows.Forms.TextBox();
            this.txtBxPayment = new System.Windows.Forms.TextBox();
            this.txtBxCharge = new System.Windows.Forms.TextBox();
            this.txtBxBalance = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(93, 61);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(49, 17);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name:";
            // 
            // lblAccountNo
            // 
            this.lblAccountNo.AutoSize = true;
            this.lblAccountNo.Location = new System.Drawing.Point(93, 131);
            this.lblAccountNo.Name = "lblAccountNo";
            this.lblAccountNo.Size = new System.Drawing.Size(89, 17);
            this.lblAccountNo.TabIndex = 2;
            this.lblAccountNo.Text = "Account No. ";
            // 
            // lblBalance
            // 
            this.lblBalance.AutoSize = true;
            this.lblBalance.Location = new System.Drawing.Point(93, 201);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(67, 17);
            this.lblBalance.TabIndex = 4;
            this.lblBalance.Text = "Balance: ";
            // 
            // lblCharge
            // 
            this.lblCharge.AutoSize = true;
            this.lblCharge.Location = new System.Drawing.Point(93, 271);
            this.lblCharge.Name = "lblCharge";
            this.lblCharge.Size = new System.Drawing.Size(62, 17);
            this.lblCharge.TabIndex = 6;
            this.lblCharge.Text = "Charge: ";
            // 
            // lblPayment
            // 
            this.lblPayment.AutoSize = true;
            this.lblPayment.Location = new System.Drawing.Point(93, 341);
            this.lblPayment.Name = "lblPayment";
            this.lblPayment.Size = new System.Drawing.Size(71, 17);
            this.lblPayment.TabIndex = 8;
            this.lblPayment.Text = "Payment: ";
            // 
            // txtBxName
            // 
            this.txtBxName.Location = new System.Drawing.Point(226, 58);
            this.txtBxName.Name = "txtBxName";
            this.txtBxName.Size = new System.Drawing.Size(206, 22);
            this.txtBxName.TabIndex = 1;
            // 
            // txtBxAccountNo
            // 
            this.txtBxAccountNo.Location = new System.Drawing.Point(226, 128);
            this.txtBxAccountNo.Name = "txtBxAccountNo";
            this.txtBxAccountNo.Size = new System.Drawing.Size(206, 22);
            this.txtBxAccountNo.TabIndex = 3;
            // 
            // txtBxPayment
            // 
            this.txtBxPayment.Location = new System.Drawing.Point(226, 338);
            this.txtBxPayment.Name = "txtBxPayment";
            this.txtBxPayment.Size = new System.Drawing.Size(206, 22);
            this.txtBxPayment.TabIndex = 9;
            // 
            // txtBxCharge
            // 
            this.txtBxCharge.Location = new System.Drawing.Point(226, 268);
            this.txtBxCharge.Name = "txtBxCharge";
            this.txtBxCharge.Size = new System.Drawing.Size(206, 22);
            this.txtBxCharge.TabIndex = 7;
            // 
            // txtBxBalance
            // 
            this.txtBxBalance.Location = new System.Drawing.Point(226, 198);
            this.txtBxBalance.Name = "txtBxBalance";
            this.txtBxBalance.Size = new System.Drawing.Size(206, 22);
            this.txtBxBalance.TabIndex = 5;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(540, 86);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(114, 64);
            this.btnUpdate.TabIndex = 10;
            this.btnUpdate.Text = "&Update Balance";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(540, 268);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(114, 64);
            this.btnReset.TabIndex = 11;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(316, 424);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(114, 64);
            this.btnExit.TabIndex = 12;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmCreditCard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(747, 547);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.txtBxBalance);
            this.Controls.Add(this.txtBxCharge);
            this.Controls.Add(this.txtBxPayment);
            this.Controls.Add(this.txtBxAccountNo);
            this.Controls.Add(this.txtBxName);
            this.Controls.Add(this.lblPayment);
            this.Controls.Add(this.lblCharge);
            this.Controls.Add(this.lblBalance);
            this.Controls.Add(this.lblAccountNo);
            this.Controls.Add(this.lblName);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmCreditCard";
            this.Text = "Update Credit Card Balance";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblAccountNo;
        private System.Windows.Forms.Label lblBalance;
        private System.Windows.Forms.Label lblCharge;
        private System.Windows.Forms.Label lblPayment;
        private System.Windows.Forms.TextBox txtBxName;
        private System.Windows.Forms.TextBox txtBxAccountNo;
        private System.Windows.Forms.TextBox txtBxPayment;
        private System.Windows.Forms.TextBox txtBxCharge;
        private System.Windows.Forms.TextBox txtBxBalance;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
    }
}

