﻿using System;
using System.Windows.Forms;

//Kristin Lau
//11/08/2016
//CreditCard -- Updates credit card balance

namespace CreditCard
{
    public partial class frmCreditCard : Form
    {
        //Declare global variables
        double dblBalance, dblCharge, dblPayment;

        public frmCreditCard()
        {
            InitializeComponent();
        }

        // Updates the balance of the credit card
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                //Convert
                dblBalance = Convert.ToDouble(txtBxBalance.Text);
                dblCharge = Convert.ToDouble(txtBxCharge.Text);
                dblPayment = Convert.ToDouble(txtBxPayment.Text);

                //Calculations
                dblBalance += (dblPayment - dblCharge);

                //Clears the charge and payment textboxes
                txtBxCharge.Text = "";
                txtBxPayment.Text = "";

                //Display new balance
                txtBxBalance.Text = dblBalance.ToString("n2");
            }
            catch (FormatException)
            {
                MessageBox.Show("You must enter a number", "ERROR");
                txtBxBalance.Focus();
            }
        } // end of Update method

        // Clears the form
        private void btnReset_Click(object sender, EventArgs e)
        {
            txtBxName.Text = "";
            txtBxAccountNo.Text = "";
            txtBxBalance.Text = "";
            txtBxCharge.Text = "";
            txtBxPayment.Text = "";
        } //end of Reset method

        // Closes the application
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        } // end of Exit method
    }
}
