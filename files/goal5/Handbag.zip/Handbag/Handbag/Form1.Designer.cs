﻿namespace Handbag
{
    partial class frmHandbags
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.findTotalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblHandbags = new System.Windows.Forms.Label();
            this.lstBxHandbags = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtbxQuantity = new System.Windows.Forms.TextBox();
            this.grpBxShipping = new System.Windows.Forms.GroupBox();
            this.radBtnShipping3 = new System.Windows.Forms.RadioButton();
            this.radBtnShipping2 = new System.Windows.Forms.RadioButton();
            this.radBtnShipping1 = new System.Windows.Forms.RadioButton();
            this.grpBxState = new System.Windows.Forms.GroupBox();
            this.radBtnMissouri = new System.Windows.Forms.RadioButton();
            this.radBtnColorado = new System.Windows.Forms.RadioButton();
            this.radBtnKansas = new System.Windows.Forms.RadioButton();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnCart = new System.Windows.Forms.Button();
            this.btnTotal = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.rchTxtBxOutput = new System.Windows.Forms.RichTextBox();
            this.addItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.goToShoppingCartToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.grpBxShipping.SuspendLayout();
            this.grpBxState.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.viewToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1239, 28);
            this.menuStrip1.TabIndex = 11;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addItemToolStripMenuItem,
            this.goToShoppingCartToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(115, 26);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.findTotalToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(53, 24);
            this.viewToolStripMenuItem.Text = "&View";
            // 
            // findTotalToolStripMenuItem
            // 
            this.findTotalToolStripMenuItem.Name = "findTotalToolStripMenuItem";
            this.findTotalToolStripMenuItem.Size = new System.Drawing.Size(169, 26);
            this.findTotalToolStripMenuItem.Text = "&Find Total";
            this.findTotalToolStripMenuItem.Click += new System.EventHandler(this.btnTotal_Click);
            // 
            // lblHandbags
            // 
            this.lblHandbags.AutoSize = true;
            this.lblHandbags.Location = new System.Drawing.Point(41, 43);
            this.lblHandbags.Name = "lblHandbags";
            this.lblHandbags.Size = new System.Drawing.Size(77, 17);
            this.lblHandbags.TabIndex = 0;
            this.lblHandbags.Text = "Hand&bags:";
            // 
            // lstBxHandbags
            // 
            this.lstBxHandbags.FormattingEnabled = true;
            this.lstBxHandbags.ItemHeight = 16;
            this.lstBxHandbags.Location = new System.Drawing.Point(44, 72);
            this.lstBxHandbags.Name = "lstBxHandbags";
            this.lstBxHandbags.Size = new System.Drawing.Size(241, 228);
            this.lstBxHandbags.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(381, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "&Quantity:";
            // 
            // txtbxQuantity
            // 
            this.txtbxQuantity.Location = new System.Drawing.Point(388, 72);
            this.txtbxQuantity.Name = "txtbxQuantity";
            this.txtbxQuantity.Size = new System.Drawing.Size(102, 22);
            this.txtbxQuantity.TabIndex = 3;
            // 
            // grpBxShipping
            // 
            this.grpBxShipping.Controls.Add(this.radBtnShipping3);
            this.grpBxShipping.Controls.Add(this.radBtnShipping2);
            this.grpBxShipping.Controls.Add(this.radBtnShipping1);
            this.grpBxShipping.Enabled = false;
            this.grpBxShipping.Location = new System.Drawing.Point(593, 43);
            this.grpBxShipping.Name = "grpBxShipping";
            this.grpBxShipping.Size = new System.Drawing.Size(243, 257);
            this.grpBxShipping.TabIndex = 6;
            this.grpBxShipping.TabStop = false;
            this.grpBxShipping.Text = "Shi&pping";
            // 
            // radBtnShipping3
            // 
            this.radBtnShipping3.AutoSize = true;
            this.radBtnShipping3.Location = new System.Drawing.Point(48, 193);
            this.radBtnShipping3.Name = "radBtnShipping3";
            this.radBtnShipping3.Size = new System.Drawing.Size(87, 21);
            this.radBtnShipping3.TabIndex = 2;
            this.radBtnShipping3.TabStop = true;
            this.radBtnShipping3.Text = "Standard";
            this.radBtnShipping3.UseVisualStyleBackColor = true;
            // 
            // radBtnShipping2
            // 
            this.radBtnShipping2.AutoSize = true;
            this.radBtnShipping2.Location = new System.Drawing.Point(48, 122);
            this.radBtnShipping2.Name = "radBtnShipping2";
            this.radBtnShipping2.Size = new System.Drawing.Size(97, 21);
            this.radBtnShipping2.TabIndex = 1;
            this.radBtnShipping2.TabStop = true;
            this.radBtnShipping2.Text = "Three-Day";
            this.radBtnShipping2.UseVisualStyleBackColor = true;
            // 
            // radBtnShipping1
            // 
            this.radBtnShipping1.AutoSize = true;
            this.radBtnShipping1.Location = new System.Drawing.Point(48, 51);
            this.radBtnShipping1.Name = "radBtnShipping1";
            this.radBtnShipping1.Size = new System.Drawing.Size(91, 21);
            this.radBtnShipping1.TabIndex = 0;
            this.radBtnShipping1.TabStop = true;
            this.radBtnShipping1.Text = "Overnight";
            this.radBtnShipping1.UseVisualStyleBackColor = true;
            // 
            // grpBxState
            // 
            this.grpBxState.Controls.Add(this.radBtnMissouri);
            this.grpBxState.Controls.Add(this.radBtnColorado);
            this.grpBxState.Controls.Add(this.radBtnKansas);
            this.grpBxState.Enabled = false;
            this.grpBxState.Location = new System.Drawing.Point(939, 43);
            this.grpBxState.Name = "grpBxState";
            this.grpBxState.Size = new System.Drawing.Size(243, 249);
            this.grpBxState.TabIndex = 7;
            this.grpBxState.TabStop = false;
            this.grpBxState.Text = "S&tate";
            // 
            // radBtnMissouri
            // 
            this.radBtnMissouri.AutoSize = true;
            this.radBtnMissouri.Location = new System.Drawing.Point(55, 193);
            this.radBtnMissouri.Name = "radBtnMissouri";
            this.radBtnMissouri.Size = new System.Drawing.Size(81, 21);
            this.radBtnMissouri.TabIndex = 2;
            this.radBtnMissouri.TabStop = true;
            this.radBtnMissouri.Text = "Missouri";
            this.radBtnMissouri.UseVisualStyleBackColor = true;
            // 
            // radBtnColorado
            // 
            this.radBtnColorado.AutoSize = true;
            this.radBtnColorado.Location = new System.Drawing.Point(55, 122);
            this.radBtnColorado.Name = "radBtnColorado";
            this.radBtnColorado.Size = new System.Drawing.Size(86, 21);
            this.radBtnColorado.TabIndex = 1;
            this.radBtnColorado.TabStop = true;
            this.radBtnColorado.Text = "Colorado";
            this.radBtnColorado.UseVisualStyleBackColor = true;
            // 
            // radBtnKansas
            // 
            this.radBtnKansas.AutoSize = true;
            this.radBtnKansas.Location = new System.Drawing.Point(55, 51);
            this.radBtnKansas.Name = "radBtnKansas";
            this.radBtnKansas.Size = new System.Drawing.Size(76, 21);
            this.radBtnKansas.TabIndex = 0;
            this.radBtnKansas.TabStop = true;
            this.radBtnKansas.Text = "Kansas";
            this.radBtnKansas.UseVisualStyleBackColor = true;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(44, 337);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(124, 53);
            this.btnAdd.TabIndex = 4;
            this.btnAdd.Text = "&Add Item";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnCart
            // 
            this.btnCart.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCart.Location = new System.Drawing.Point(356, 337);
            this.btnCart.Name = "btnCart";
            this.btnCart.Size = new System.Drawing.Size(184, 53);
            this.btnCart.TabIndex = 5;
            this.btnCart.Text = "Go to Shopping &Cart";
            this.btnCart.UseVisualStyleBackColor = true;
            this.btnCart.Click += new System.EventHandler(this.btnCart_Click);
            // 
            // btnTotal
            // 
            this.btnTotal.Enabled = false;
            this.btnTotal.Location = new System.Drawing.Point(728, 337);
            this.btnTotal.Name = "btnTotal";
            this.btnTotal.Size = new System.Drawing.Size(143, 53);
            this.btnTotal.TabIndex = 8;
            this.btnTotal.Text = "&Find Total";
            this.btnTotal.UseVisualStyleBackColor = true;
            this.btnTotal.Click += new System.EventHandler(this.btnTotal_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(1059, 337);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(124, 53);
            this.btnExit.TabIndex = 9;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // rchTxtBxOutput
            // 
            this.rchTxtBxOutput.Font = new System.Drawing.Font("Courier New", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchTxtBxOutput.Location = new System.Drawing.Point(44, 425);
            this.rchTxtBxOutput.Name = "rchTxtBxOutput";
            this.rchTxtBxOutput.ReadOnly = true;
            this.rchTxtBxOutput.Size = new System.Drawing.Size(1151, 307);
            this.rchTxtBxOutput.TabIndex = 10;
            this.rchTxtBxOutput.Text = "";
            // 
            // addItemToolStripMenuItem
            // 
            this.addItemToolStripMenuItem.Name = "addItemToolStripMenuItem";
            this.addItemToolStripMenuItem.Size = new System.Drawing.Size(220, 26);
            this.addItemToolStripMenuItem.Text = "&Add Item";
            this.addItemToolStripMenuItem.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // goToShoppingCartToolStripMenuItem
            // 
            this.goToShoppingCartToolStripMenuItem.Name = "goToShoppingCartToolStripMenuItem";
            this.goToShoppingCartToolStripMenuItem.Size = new System.Drawing.Size(220, 26);
            this.goToShoppingCartToolStripMenuItem.Text = "Go to Shopping &Cart";
            this.goToShoppingCartToolStripMenuItem.Click += new System.EventHandler(this.btnCart_Click);
            // 
            // frmHandbags
            // 
            this.AcceptButton = this.btnAdd;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1239, 760);
            this.Controls.Add(this.rchTxtBxOutput);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnTotal);
            this.Controls.Add(this.btnCart);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.grpBxState);
            this.Controls.Add(this.grpBxShipping);
            this.Controls.Add(this.txtbxQuantity);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lstBxHandbags);
            this.Controls.Add(this.lblHandbags);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmHandbags";
            this.Text = "Handbags Order Form";
            this.Load += new System.EventHandler(this.frmHandbags_Load);
            this.Click += new System.EventHandler(this.btnExit_Click);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpBxShipping.ResumeLayout(false);
            this.grpBxShipping.PerformLayout();
            this.grpBxState.ResumeLayout(false);
            this.grpBxState.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.Label lblHandbags;
        private System.Windows.Forms.ListBox lstBxHandbags;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtbxQuantity;
        private System.Windows.Forms.GroupBox grpBxShipping;
        private System.Windows.Forms.RadioButton radBtnShipping3;
        private System.Windows.Forms.RadioButton radBtnShipping2;
        private System.Windows.Forms.RadioButton radBtnShipping1;
        private System.Windows.Forms.GroupBox grpBxState;
        private System.Windows.Forms.RadioButton radBtnMissouri;
        private System.Windows.Forms.RadioButton radBtnColorado;
        private System.Windows.Forms.RadioButton radBtnKansas;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnCart;
        private System.Windows.Forms.Button btnTotal;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.RichTextBox rchTxtBxOutput;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem findTotalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addItemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem goToShoppingCartToolStripMenuItem;
    }
}

