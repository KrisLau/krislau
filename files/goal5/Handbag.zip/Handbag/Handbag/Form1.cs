﻿using System;
using System.Windows.Forms;

//Kristin Lau
//04/20/207
//Handbag

namespace Handbag
{
    public partial class frmHandbags : Form
    {
        //Global arrays of handbag types and their prices
        double dblSubtotal = 0; 
        string strOutput = "Selection".PadRight(30) + "Unit Price".PadRight(20) + "Quantity".PadRight(20) + "Extended Price" + "\n";
        string[] Handbags = new string[] { "Full Decorative", "Beaded", "Needlepoint Design", "Fringed", "Fringed Beaded", "Plain" };
        double[] Prices = new double[] { 50, 45, 40, 25, 30, 20 };

        public frmHandbags()
        {
            InitializeComponent();
        }//end frmHandbag

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }//end btnExit

        private void frmHandbags_Load(object sender, EventArgs e)
        {
            //Add formatted string of items into array
            for(int i = 0; i < Handbags.Length; i++)
            {
                lstBxHandbags.Items.Add(Handbags[i] + " -- " + Prices[i].ToString("c2"));
            }//end for
        }//end frmHandbags_Load

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Declare variables
            string strHandbag, strQuantity;
            double dblPrice, dblExtendedPrice;
            int intQuantity;

            try
            {
                //Read Input & Convert
                strHandbag = Handbags[lstBxHandbags.SelectedIndex];
                dblPrice = Prices[lstBxHandbags.SelectedIndex];

                strQuantity = txtbxQuantity.Text;
                intQuantity = Convert.ToInt32(strQuantity);
                if(intQuantity <= 0)
                {
                    txtbxQuantity.Focus();
                    txtbxQuantity.SelectAll();
                    MessageBox.Show("Please enter a positive number greater than 0.", "Error");
                }

                //Call FindExtendedPrice mthod
                dblExtendedPrice = FindExtendedPrice(dblPrice, intQuantity);

                //Sum
                dblSubtotal += dblExtendedPrice;

                //Format output string
                strOutput += strHandbag.PadRight(30) + dblPrice.ToString("c2").PadLeft(10) +
                    strQuantity.PadLeft(18).PadRight(20) + dblExtendedPrice.ToString("c2").PadLeft(24) + "\n";

                //Display
                rchTxtBxOutput.Text = strOutput;

                //Focus and clear
                lstBxHandbags.ClearSelected();
                lstBxHandbags.Focus();
                txtbxQuantity.Clear();
            }//end try

            catch (IndexOutOfRangeException)
            {
                lstBxHandbags.Focus();
                MessageBox.Show("Please select a handbag from the list.", "Error");
            }

            catch (FormatException)
            {
                txtbxQuantity.Focus();
                txtbxQuantity.SelectAll();
                MessageBox.Show("Please enter a number.", "Error");
            }//end catch
        }//end btnAdd

        private void btnCart_Click(object sender, EventArgs e)
        {
            //Disable btnAdd
            btnAdd.Enabled = false;

            //Enable Shipping and State group boxes
            grpBxShipping.Enabled = true;
            grpBxState.Enabled = true;

            //Enable btnTotal
            btnTotal.Enabled = true;
        }//end btnCart

        private void btnTotal_Click(object sender, EventArgs e)
        {
            //Declare variables
            double dblTax, dblShipping, dblTotal;

            //Read Input & call methods
            dblShipping = FindShipping(dblSubtotal, radBtnShipping1, radBtnShipping2, radBtnShipping3);
            dblTax = FindTax(dblSubtotal, radBtnKansas, radBtnColorado, radBtnMissouri);

            //Calculate total & check if user has checked both radio buttons for shipping and state
            if (dblShipping != -1 && dblTax != -1)
            {
                dblTotal = dblSubtotal + dblShipping + dblTax;
            }//end if

            else
            {
                dblTotal = -1;
                MessageBox.Show("Please select both a shipping option and your state.", "Error");
            }//end else
            
            //Format output string
            strOutput += "\nSubtotal: " + dblSubtotal.ToString("c2") + "\nTax: " + dblTax.ToString("c2") + "\nShipping: " + 
                dblShipping.ToString("c2") + "\nTotal: " + dblTotal.ToString("c2");

            //Display
            rchTxtBxOutput.Text = strOutput;

            //Reset all globals
            dblSubtotal = 0;
            strOutput = "Selection".PadRight(30) + "Unit Price".PadRight(20) + "Quantity".PadRight(20) + "Extended Price" + "\n";

            //Enable btnAdd
            btnAdd.Enabled = true;

            //Disable group boxes
            grpBxShipping.Enabled = false;
            grpBxState.Enabled = false;
        }//end btnTotal

        //****************Methods*******************
        //Calculate extended price
        public static double FindExtendedPrice(double price, int quantity)
        {
            double dblExtendedPrice;

            dblExtendedPrice = price * quantity;

            return dblExtendedPrice;
        }//end FindExtendedPrice

        //Assigns shipping price
        public static double FindShipping(double subtotal, RadioButton radBtnShipping1, RadioButton radBtnShipping2, RadioButton radBtnShipping3)
        {
            double dblShipping;

            const double
                OVERNIGHT = 0.1,
                THREE_DAY = 0.07,
                STANDARD = 0.05;

            if (radBtnShipping1.Checked == true)
            {
                dblShipping = subtotal * OVERNIGHT;
            }//end if

            else if (radBtnShipping2.Checked == true)
            {
                dblShipping = subtotal * THREE_DAY;
            }//end else if

            else if (radBtnShipping3.Checked == true)
            {
                dblShipping = subtotal * STANDARD;
            }//end else if

            else
            {
                dblShipping = -1;
            }//end else

            return dblShipping;
        }//end FindShipping

        //Calculates Tax
        public static double FindTax(double subtotal, RadioButton radBtnKansas, RadioButton radBtnColorado, RadioButton radBtnMissouri)
        {
            double dblTax;

            const double
                KANSAS = 0.07,
                COLORADO = 0.08,
                MISSOURI = 0.065;

            //Calculate tax
            if (radBtnKansas.Checked == true)
            {
                dblTax = subtotal * KANSAS;
            }//end if

            else if (radBtnColorado.Checked == true)
            {
                dblTax = subtotal * COLORADO;
            }//end else if

            else if (radBtnMissouri.Checked == true)
            {
                dblTax = subtotal * MISSOURI;
            }//end else if

            else
            {
                dblTax = -1;
            }//end else

            return dblTax;
        }//end FindTax
    }//end class
}//end namespace
